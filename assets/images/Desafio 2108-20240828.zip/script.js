const API_KEY = '70c1e295ba1e8c8b89b5fea784cb617f';
const BASE_URL = 'https://api.themoviedb.org/3';

async function buscarFilme() {
    const titulo = document.getElementById('searchInput').value;
    const resultadoDiv = document.getElementById('resultado');
    
    if (titulo === '') {
        resultadoDiv.innerHTML = '<p>Por favor, digite um título de filme.</p>';
        return;
    }
    
    try {
        const resposta = await fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(titulo)}`);
        const dados = await resposta.json();
        
        if (dados.results.length > 0) {
            const filme = dados.results[0];
            resultadoDiv.innerHTML = `
                <h3>${filme.title}</h3>
                <p><strong>Data de Lançamento:</strong> ${filme.release_date}</p>
                <p><strong>Resumo:</strong> ${filme.overview}</p>
                <img src="https://image.tmdb.org/t/p/w500${filme.poster_path}" alt="${filme.title}" style="width:200px;">
            `;
        } else {
            resultadoDiv.innerHTML = '<p>Filme não encontrado.</p>';
        }
    } catch (erro) {
        resultadoDiv.innerHTML = '<p>Erro ao buscar filme. Tente novamente mais tarde.</p>';
    }
}

async function carregarGeneros() {
    const generosDiv = document.getElementById('generos');
    
    try {
        const resposta = await fetch(`${BASE_URL}/genre/movie/list?api_key=${API_KEY}`);
        const dados = await resposta.json();
        
        const generos = dados.genres;
        generosDiv.innerHTML = generos.map(genre => `<p>${genre.name}</p>`).join('');
    } catch (erro) {
        generosDiv.innerHTML = '<p>Erro ao carregar gêneros. Tente novamente mais tarde.</p>';
    }
}
